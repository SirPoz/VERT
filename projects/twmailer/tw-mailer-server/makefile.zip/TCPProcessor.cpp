#include "TCPParse.cpp"
#include "filehandler.cpp"
#include "model/Email.cpp"

class TCPProcessor{
    public:
        TCPProcessor(string spool, string username, int client, TCPParse * parse);
        string message;
    private:
        filehandler * spoolhandler;    
        
};

TCPProcessor::TCPProcessor(string spool, string username, int client, TCPParse * parse)
{
    printf("processor start method: ");
    printf(parse->method.c_str());
    string message = "";
    spoolhandler = new filehandler();

    if(strcmp(parse->method.c_str(), "SEND") == 0)
    {
        email mail = email(username, parse->receiver, parse->subject, parse->body);
        message = spoolhandler->writemailfile(&mail,spool);

    }
    if(strcmp(parse->method.c_str(), "LIST") == 0)
    {
         message = spoolhandler->create_mail_list(username, spool);
    }
    if(strcmp(parse->method.c_str(), "READ") == 0)
    {
         message = spoolhandler->readfile(username,parse->number,spool);
    }
    if(strcmp(parse->method.c_str(), "DEL") == 0)
    {
         message = spoolhandler->deletefile(username, parse->number,spool);
    }
    printf("message length:%d\n",message.length());
    printf("message in processor:");
    printf(message.c_str());
    printf("\n");
    if(message.length() <= 0)
    {

        message = "ERR\n";
    }
    
}